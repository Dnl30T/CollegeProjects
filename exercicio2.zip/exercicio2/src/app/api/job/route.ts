import { NextApiRequest, NextApiResponse } from "next";
import { db } from "../../db";
import { NextResponse } from "next/server";

export async function GET(){
  const job = await db.job.findMany();
  return NextResponse.json({
      job
  })
}