import { NextApiRequest, NextApiResponse } from "next";
import { db } from "../../db";
import { NextResponse } from "next/server";

export async function GET(){
    const department = await db.department.findMany();
    return NextResponse.json({
        department
    })
  }